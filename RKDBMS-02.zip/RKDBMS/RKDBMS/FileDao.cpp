#include "stdafx.h"
#include "FileDao.h"


CFileDao::CFileDao()
{
}


CFileDao::~CFileDao()
{
}
