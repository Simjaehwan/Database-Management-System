#pragma once

#include "FileHelper.h"

class CFileDao
{
public:
	CFileDao();
	~CFileDao();


};

