//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RKDBMS.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_RKDBMSTYPE                  130
#define ID_RUANKO_TITLE                 310
#define IDD_OPEN_DATABASE_DLG           311
#define IDD_CREATE_DATABASE_DLG         312
#define IDD_NEW_TABLE_DLG               313
#define IDD_ADD_FIELD_DLG               314
#define IDD_INSERT_RECORD               315
#define IDI_ICON1                       330
#define IDI_ICON_DB                     331
#define IDI_ICON_CLOSE                  338
#define IDI_ICON3                       339
#define IDI_ICON_MINIMIZE               339
#define IDC_DATABASE_NAME_LIST          1000
#define IDC_EDIT1                       1001
#define IDC_DATA_TYPE_LIST              1002
#define IDC_FIELD_DEFAULT_VALUE         1003
#define IDC_PRIMARY_KEY                 1004
#define IDC_NOT_NULL                    1005
#define IDC_FIELD_NAME                  1006
#define IDC_LIST1                       1007
#define ID_DATABASE_CREATEDATABASE      32771
#define ID_DATABASE_OPENDATABASE        32772
#define IDM_CREATE_DATABASE             32773
#define IDM_OPEN_DATABASE               32774
#define ID_TABLE_NEWTABLE               32775
#define ID_Menu                         32776
#define ID_TABLE_OPENTABLE              32777
#define ID_TABLE_DELETETABLE            32778
#define IDM_NEW_TABLE                   32779
#define IDM_MODIFY_TABLE                32780
#define IDM_OPEN_TABLE                  32781
#define IDM_DELETE_TABLE                32782
#define ID_FIELD_ADDFIELD               32783
#define ID_FIELD_MODIFYFIELD            32784
#define ID_FIELD_DELETEFIELD            32785
#define IDM__ADD_FIELD                  32786
#define IDM_ADD_FIELD                   32787
#define IDM_MODIFY_FIELD                32788
#define IDM_DELETE_FIELD                32789
#define ID_RECORD_ADDRECORD             32790
#define ID_RECORD_MODIFYRECORD          32791
#define ID_RECORD_DELETERECORD          32792
#define IDM_ADD_RECORD                  32793
#define IDM_MODIFY_RECORD               32794
#define IDM_DELETE_RECORD               32795
#define ID_TESTMENU_TESTMENU            32796
#define IDM_TEST_MENU                   32797
#define ID_RECORD_QUERYRECORDS          32798
#define IDM_QUERY_RECORDS               32799

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        340
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           311
#endif
#endif
