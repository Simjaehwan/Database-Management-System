#pragma once


// CreateDatabase �Ի���

class CreateDatabase : public CDialogEx
{
	DECLARE_DYNAMIC(CreateDatabase)

public:
	CreateDatabase(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CreateDatabase();

// �Ի�������
	enum { IDD = IDD_CREATEDATABASE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CString dbname;
};
